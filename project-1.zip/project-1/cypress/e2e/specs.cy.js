describe('Тестирование модуля Вакансии', () => {
    const baseUrl = 'https://dev.profteam.su';
    const credentials = {
        student: { username: 'testerStudent', password: 'Password1' },
        employer: { username: 'testerEmployer', password: 'Password1' },
    };

    beforeEach(() => {
        cy.visit(baseUrl);
    });

    it('Авторизация работодателя', () => {
        cy.get('#login').type(credentials.employer.username);
        cy.get('#password').type(credentials.employer.password);
        cy.get('button[type=submit]').click();
        cy.url().should('include', '/dashboard');
    });

    it('Создание новой вакансии', () => {
        cy.login(credentials.employer.username, credentials.employer.password);
        cy.get('a[href="/vacancies"]') // Переход в раздел "Вакансии"
          .click();
        cy.get('button#create-vacancy')
          .click();
        cy.get('#title').type('Тестовая вакансия');
        cy.get('#description').type('Описание тестовой вакансии');
        cy.get('#salary').type('50000');
        cy.get('button[type=submit]').click();
        cy.contains('Тестовая вакансия').should('exist');
    });

    it('Поиск вакансии', () => {
        cy.get('#search').type('Тестовая вакансия');
        cy.get('button#search-button').click();
        cy.contains('Тестовая вакансия').should('be.visible');
    });

    it('Отклик на вакансию студентом', () => {
        cy.login(credentials.student.username, credentials.student.password);
        cy.visit('/vacancies');
        cy.contains('Тестовая вакансия').click();
        cy.get('button#apply').click();
        cy.contains('Отклик отправлен').should('be.visible');
    });

    it('Подтверждение отклика работодателем', () => {
        cy.login(credentials.employer.username, credentials.employer.password);
        cy.visit('/applications');
        cy.contains('Тестовая вакансия').click();
        cy.get('button#approve').click();
        cy.contains('Отклик подтвержден').should('be.visible');
    });

    it('Отправка сообщения в рабочем пространстве', () => {
        cy.login(credentials.student.username, credentials.student.password);
        cy.visit('/workspace');
        cy.get('#message-input').type('Здравствуйте!');
        cy.get('button#send-message').click();
        cy.contains('Здравствуйте!').should('be.visible');
    });

    it('Смена статуса рабочего пространства', () => {
        cy.login(credentials.employer.username, credentials.employer.password);
        cy.visit('/workspace');
        cy.get('#status-select').select('Завершено');
        cy.get('button#save-status').click();
        cy.contains('Статус: Завершено').should('be.visible');
    });

    Cypress.Commands.add('login', (username, password) => {
        cy.visit('https://dev.profteam.su');
    
        // Дождаться загрузки формы логина
        cy.get('input[autocomplete="username"]', { timeout: 10000 }).should('be.visible').type(username);
        cy.get('input[autocomplete="current-password"]').should('be.visible').type(password);
    
        // Кликнуть по кнопке "Войти"
        cy.get('button[type="submit"]').click();
    
        // Проверить, что логин успешен (например, редирект на /dashboard)
        cy.url().should('include', '/dashboard');
    });
});